import mongoose, { Document, Schema } from 'mongoose';

export interface IUrl extends Document {
  originalUrl: string;
  parameters: Record<string, string>;
  newUrl: string;
  createdAt: Date;
}

const UrlSchema: Schema = new Schema({
  originalUrl: { type: String, required: true },
  parameters: { type: Schema.Types.Mixed, required: true },
  newUrl: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model<IUrl>('Url', UrlSchema);