import Url, { IUrl } from '../models/Link';

export class UrlService {
  /**
   * Append parameters to a URL and return the new URL document.
   *
   * @param {string} originalUrl - The original URL
   * @param {Record<string, string>} parameters - The parameters to append to the URL
   * @returns {Promise<IUrl>} - The new URL document
   */
  static async appendParameters(originalUrl: string, parameters: Record<string, string>): Promise<IUrl> {
    const url = new URL(originalUrl);
    
    Object.entries(parameters).forEach(([key, value]) => {
      url.searchParams.append(key, value);
    });

    const newUrl = url.toString();

    const urlDoc = new Url({
      originalUrl,
      parameters,
      newUrl,
    });

    await urlDoc.save();

    return urlDoc;
  }

  static async getLinks(page: number = 1, limit: number = 10): Promise<{ links: IUrl[], totalPages: number }> {
     // Calculate skip and limit
    const skip = (page - 1) * limit;
    const totalDocs = await Url.countDocuments();
    const totalPages = Math.ceil(totalDocs / limit);

    const links = await Url.find()
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    return { links, totalPages };
  }
}