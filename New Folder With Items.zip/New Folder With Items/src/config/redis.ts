import { createClient } from 'redis';
import dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

// Log Redis connection info
console.log(`Connecting to Redis at ${process.env.REDIS_HOST}:${process.env.REDIS_PORT}`);

// Create a Redis client
const redisClient = createClient({
  url: `redis://${process.env.REDIS_HOST}:${process.env.REDIS_PORT}`,
});

// Handle connection errors
redisClient.on('error', (err) => {
  console.error('Redis connection error:', err);
});

// Handle successful connection
redisClient.on('connect', () => {
  console.log('Connected to Redis');
});

// Connect the Redis client
(async () => {
  try {
    await redisClient.connect();
  } catch (error) {
    console.error('Error connecting to Redis:', error);
  }
})();

// Export the Redis client for use in other modules
export default redisClient;
