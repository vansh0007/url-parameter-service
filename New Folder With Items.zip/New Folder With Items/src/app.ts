import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import {urlRouter} from './routes/linkRoutes';
import { errorHandler } from './middlewares/errorHandler';
const cors = require('cors');


dotenv.config();

const app = express();
const PORT = process.env.PORT ?? 3001;

// Middleware
app.use(express.json());
app.use(cors());

// Error handler
app.use(errorHandler);


// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(
      process.env.MONGODB_URI ?? "mongodb+srv://vanshbhatia9:V3h14BR72YsM00In@cluster.onwa0.mongodb.net/?retryWrites=true&w=majority&appName=Cluster",{}
    );
    console.log('Connected to MongoDB Atlas');
  } catch (error) {
    console.error('MongoDB connection error:', error);
    process.exit(1);
  }
};
  
  connectDB();
  
// Routes
app.use('/api/v1', urlRouter);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
 
